<?php
	return array(
		'test' => 'test',
	);

/*
	Omit PHP closing tag to help avoid accidental output
*/